# 📚 Book Finder App

## Overview
A simple web application that allows users to search for books using the Open Library API.

## Features
- Search books by title
- View book title, author, and cover image
- Handles loading and errors
- Fully responsive UI

## Tech Stack
- ReactJS
- Tailwind CSS
- Axios
- OpenLibrary API

## How to Run Locally
1. Clone the repo
2. Run `npm install`
3. Run `npm start`

## Deployment
Hosted on CodeSandbox: [https://codesandbox.io/p/sandbox/jdghv8?file=%2FREADME.md%3A24%2C25]
