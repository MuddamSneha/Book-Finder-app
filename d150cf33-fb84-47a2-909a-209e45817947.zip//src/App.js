import React, { useState } from "react";
import axios from "axios";

function App() {
  const [query, setQuery] = useState("");
  const [books, setBooks] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const searchBooks = async () => {
    if (!query.trim()) {
      setError("Please enter a book title.");
      return;
    }
    setLoading(true);
    setError("");
    setBooks([]);

    try {
      const response = await axios.get(
        `https://openlibrary.org/search.json?title=${query}`
      );
      const results = response.data.docs.slice(0, 12);
      if (results.length === 0) {
        setError("No results found.");
      } else {
        setBooks(results);
      }
    } catch (err) {
      setError("Something went wrong. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-4xl font-bold text-center mb-6 text-blue-700">
        📚 Book Finder
      </h1>

      <div className="flex justify-center gap-2 mb-8">
        <input
          type="text"
          className="border border-gray-300 rounded-lg p-2 w-64"
          placeholder="Enter book title..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && searchBooks()}
        />
        <button
          onClick={searchBooks}
          className="bg-blue-600 text-white px-4 rounded-lg hover:bg-blue-700"
        >
          Search
        </button>
      </div>

      {loading && <p className="text-center text-gray-500">Loading...</p>}
      {error && <p className="text-center text-red-600">{error}</p>}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {books.map((book, index) => (
          <div
            key={index}
            className="bg-white shadow-md rounded-lg p-4 hover:scale-105 transition-transform"
          >
            {book.cover_i ? (
              <img
                src={`https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`}
                alt={book.title}
                className="mx-auto mb-3 rounded"
              />
            ) : (
              <div className="h-40 flex items-center justify-center bg-gray-200 rounded mb-3 text-gray-500">
                No Image
              </div>
            )}
            <h2 className="font-semibold text-lg">{book.title}</h2>
            <p className="text-sm text-gray-600">
              {book.author_name ? book.author_name[0] : "Unknown Author"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
